from django import forms
# from accounts.models import AccountUser

# class UserEditForm(forms.ModelForm):
#     class Meta:
#         model = AccountUser
#         fields = ['username', 'email', 'birthdate', 'phone_number', 'address', 'gender']  # 수정하고 싶은 필드 목록
        
        
